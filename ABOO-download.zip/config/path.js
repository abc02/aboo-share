const path = require('path')

module.exports = {
     sourcePath: path.join(__dirname, '../src/'),
     outputPath: path.join(__dirname, '../build/')
}